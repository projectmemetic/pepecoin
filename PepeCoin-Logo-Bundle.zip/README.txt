PepeCoin / PEPE logo bundle

You can use either logo, if one style fits your exchange better than the other.